<?php
include 'includes/header.php';
include 'includes/nav.php';
?>
<div id="main">
	
</div>
<?php
include 'includes/footer.php';
?>