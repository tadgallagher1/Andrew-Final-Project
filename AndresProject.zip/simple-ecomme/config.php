<?php
	ini_set('display_errors',1);
	error_reporting(-1);
	define('DB_HOST', 'localhost');
    define('DB_USER', 'someuser1');
    define('DB_PASSWORD', 'Hello123');
    define('DB_DATABASE', 'idukan');
    
?>