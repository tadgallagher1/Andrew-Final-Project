</div> <!-- wrap -->
<footer>
      <div class="container">
        <p>&copy; Andrew Moore</p>
      </div>
    </footer>
  </body>
</html>
