<?php
include 'includes/header.php';
include 'includes/nav.php';
?>
<div id="main">
	<header class="container">
		<h3 class="page-header">Contact</h3>
	</header>
	<div class="container">
		<div class="row">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d450942.73567663156!2d-82.73447112343412!3d27.994198599401237!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88c2b782b3b9d1e1%3A0xa75f1389af96b463!2sTampa%2C%20FL!5e0!3m2!1sen!2sus!4v1604029467634!5m2!1sen!2sus" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>			
		</div>
	</div>
</div>
<?php
include 'includes/footer.php';
?>